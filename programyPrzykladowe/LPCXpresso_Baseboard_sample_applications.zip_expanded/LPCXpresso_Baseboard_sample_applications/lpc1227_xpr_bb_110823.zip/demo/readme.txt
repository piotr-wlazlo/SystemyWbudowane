demo
=====================
- Moving the joystick will draw on the OLED display
- Turning the rotary switch will control the 7-segment display
- The accelerometer will control a running pattern on the LEDs connected to the PCA9532
- Turning the trim potentiometer will control the RBG LED
- Pressing SW3 button will play a song on the speaker

The project makes use of code from the following library projects:
- CMSIS 	  : for CMSIS files
- MCU_Lib         : for LPC12xx peripheral driver files
- EaBaseBoard_Lib : for Embedded Artists LPCXpresso Base Board peripheral drivers

These library projects must exist in the same workspace in order
for the project to successfully build.

