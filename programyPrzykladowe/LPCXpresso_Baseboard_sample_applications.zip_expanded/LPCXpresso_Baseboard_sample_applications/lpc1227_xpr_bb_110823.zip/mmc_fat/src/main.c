/*****************************************************************************
 *   This example shows how to access an MMC/SD card
 *
 *   Copyright(C) 2009, Embedded Artists AB
 *   All rights reserved.
 *
 ******************************************************************************/



#include "mcu_regs.h"
#include "lpc_types.h"
#include "board.h"
#include "uart.h"
#include "stdio.h"
#include "timer32.h"

#include "gpio.h"
#include "ssp.h"

#include "diskio.h"
#include "ff.h"


static FILINFO Finfo;
static FATFS Fatfs[1];
static uint8_t buf[64];

void SysTick_Handler(void) {
  disk_timerproc();
}


/* Main Program */

int main (void) {
  DSTATUS stat;
  DWORD p2;
  WORD w1;
  BYTE res, b1;
  DIR dir;

  int i = 0;

  SSP_InitTypeDef SSP_InitStructure;

  brd_delay_init();
  brd_usb_uart_init();


  UART_SendString(DEV_USB_UART, (uint8_t*)"MMC/SD example\r\n");

  SSP_StructInit(&SSP_InitStructure);
  SSP_Init(&SSP_InitStructure);
  SSP_Cmd (ENABLE);

  SysTick_Config(SystemCoreClock / 100);


  brd_delayMs(500);

  stat = disk_initialize(0);
  if (stat & STA_NOINIT) {
    UART_SendString(DEV_USB_UART, (uint8_t*)"MMC: not initialized\r\n");
  }

  if (stat & STA_NODISK) {
    UART_SendString(DEV_USB_UART, (uint8_t*)"MMC: No Disk\r\n");
  }

  if (stat != 0) {
    return 1;
  }

  UART_SendString(DEV_USB_UART, (uint8_t*)"MMC: Initialized\r\n");

  if (disk_ioctl(0, GET_SECTOR_COUNT, &p2) == RES_OK) {
    i = sprintf((char*)buf, "Drive size: %d \r\n", p2);
    UART_Send(DEV_USB_UART,buf, i, UART_BLOKING_TIMEOUT);
  }

  if (disk_ioctl(0, GET_SECTOR_SIZE, &w1) == RES_OK) {
    i = sprintf((char*)buf, "Sector size: %d \r\n", w1);
    UART_Send(DEV_USB_UART,buf, i, UART_BLOKING_TIMEOUT);
  }

  if (disk_ioctl(0, GET_BLOCK_SIZE, &p2) == RES_OK) {
    i = sprintf((char*)buf, "Erase block size: %d \r\n", p2);
    UART_Send(DEV_USB_UART,buf, i, UART_BLOKING_TIMEOUT);
  }

  if (disk_ioctl(0, MMC_GET_TYPE, &b1) == RES_OK) {
    i = sprintf((char*)buf, "Card type: %d \r\n", b1);
    UART_Send(DEV_USB_UART,buf, i, UART_BLOKING_TIMEOUT);
  }

  res = f_mount(0, &Fatfs[0]);
  if (res != FR_OK) {
    i = sprintf((char*)buf, "Failed to mount 0: %d \r\n", res);
    UART_Send(DEV_USB_UART,buf, i, UART_BLOKING_TIMEOUT);
    return 1;
  }

  res = f_opendir(&dir, "/");
  if (res) {
    i = sprintf((char*)buf, "Failed to open /: %d \r\n", res);
    UART_Send(DEV_USB_UART,buf, i, UART_BLOKING_TIMEOUT);
    return 1;
  }

  for(;;) {
    res = f_readdir(&dir, &Finfo);
    if ((res != FR_OK) || !Finfo.fname[0]) break;

    UART_SendString(DEV_USB_UART, (uint8_t*)&(Finfo.fname[0]));
    UART_SendString(DEV_USB_UART, (uint8_t*)"\r\n");

  }


  while(1);


}
