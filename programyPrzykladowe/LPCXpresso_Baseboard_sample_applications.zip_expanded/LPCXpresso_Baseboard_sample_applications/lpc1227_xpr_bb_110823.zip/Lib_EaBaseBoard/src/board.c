/*****************************************************************************
 *   board.c:  Board configurations and helper functions
 *
 *   Copyright(C) 2011, Embedded Artists AB
 *   All rights reserved.
 *
 ******************************************************************************/


/******************************************************************************
 * Includes
 *****************************************************************************/

#include "mcu_regs.h"
#include "lpc_types.h"
#include "board.h"
#include "timer32.h"
#include "iocon.h"
#include "uart.h"
#include "sysctrl.h"

/******************************************************************************
 * Defines and typedefs
 *****************************************************************************/



/******************************************************************************
 * External global variables
 *****************************************************************************/

/******************************************************************************
 * Local variables
 *****************************************************************************/


/******************************************************************************
 * Local Functions
 *****************************************************************************/

/******************************************************************************
 * Public Functions
 *****************************************************************************/

/******************************************************************************
 *
 * Description:
 *    Initialize delay helper function. Using timer32_0
 *
 *****************************************************************************/
void brd_delay_init (void)
{
  TIM32_InitTypeDef init;

  init.PrescaleOption = TIM32_PRESCALE_TICKVAL;
  init.PrescaleValue = 1;

  TIM32_Init(DEV_DELAY, TIM32_MODE_TIMER, &init);
}

/******************************************************************************
 *
 * Description:
 *    Delay function
 *
 * Params:
 *     delay - number of milliseconds to delay
 *
 *****************************************************************************/
void brd_delayMs(uint32_t delay)
{
  TIM32_MATCHTypeDef match = {0};

  TIM32_ResetCounter(DEV_DELAY);

  match.MatchChannel = TIM32_MATCH_CHANNEL0;
  match.StopOnMatch = TRUE;
  match.MatchValue = delay * ((SystemCoreClock/LPC_SYSCON->SYSAHBCLKDIV) / 1000);
  TIM32_ConfigMatch(DEV_DELAY, &match);
  TIM32_Cmd(DEV_DELAY, ENABLE);

  while(DEV_DELAY->TCR & 0x01);
}

/******************************************************************************
 *
 * Description:
 *    Delay function
 *
 * Params:
 *     delay - number of microseconds to delay
 *
 *****************************************************************************/
void brd_delayUs(uint32_t delay)
{
  TIM32_MATCHTypeDef match = {0};

  TIM32_ResetCounter(DEV_DELAY);

  match.MatchChannel = TIM32_MATCH_CHANNEL0;
  match.StopOnMatch = TRUE;
  match.MatchValue = delay * ((SystemCoreClock/LPC_SYSCON->SYSAHBCLKDIV) / 1000000);
  TIM32_ConfigMatch(DEV_DELAY, &match);
  TIM32_Cmd(DEV_DELAY, ENABLE);

  while(DEV_DELAY->TCR & 0x01);
}

void brd_usb_uart_init(void)
{
  IOCON_PIO_CFG_Type PIO_mode;
  UART_CFG_Type uartCfg;

  IOCON_StructInit(&PIO_mode);
  PIO_mode.type = IOCON_UART_RXD0_LOC0;
  IOCON_SetFunc(&PIO_mode);
  PIO_mode.type = IOCON_UART_TXD0_LOC0;
  IOCON_SetFunc(&PIO_mode);

  SYS_ResetPeripheral(SYS_PRESETCTRL_UART0_RST,DISABLE);
  SYS_ConfigAHBCLK(SYS_AHBCLKCTRL_UART0, ENABLE);
  SYS_SetUART0ClockDiv(1);

  UART_Init(DEV_USB_UART);
  uartCfg.baudrate = 115200;
  uartCfg.databits = UART_CFG_DATABIT_8;
  uartCfg.stopbits = UART_CFG_STOPBIT_1;
  uartCfg.parity   = UART_CFG_PARITY_NONE;
  uartCfg.fifodma  = UART_CFG_DMAMODE_DISABLE;
  uartCfg.fifolevel= UART_CFG_FIFOTRG_1;
  uartCfg.txdbreak = UART_CFG_TXDBREAK_DISABLE;

  UART_SetConfig(DEV_USB_UART, &uartCfg);
  UART_ConfigTXD(DEV_USB_UART, ENABLE);

}

void brd_trimpot_init(void)
{
  IOCON_PIO_CFG_Type PIO_mode;

  IOCON_StructInit (&PIO_mode);
  PIO_mode.type = IOCON_ADC_AD0;
  IOCON_SetFunc (&PIO_mode);
}

void brd_bnc_init(void)
{
  IOCON_PIO_CFG_Type PIO_mode;

  IOCON_StructInit (&PIO_mode);
  PIO_mode.type = IOCON_ADC_AD5;
  IOCON_SetFunc (&PIO_mode);
}


