/*****************************************************************************
 *   This example is controlling the RGB LED using the joystick
 *
 *   Copyright(C) 2009, Embedded Artists AB
 *   All rights reserved.
 *
 ******************************************************************************/


#include "lpc_types.h"
#include "board.h"
#include "uart.h"
#include "stdio.h"
#include "timer32.h"
#include "gpio.h"

#include "joystick.h"
#include "rgb.h"


int main (void) {

    uint8_t r = 0;
    uint8_t g = 0;
    uint8_t b = 0;

    uint8_t joy = 0;


    brd_delay_init();
    brd_usb_uart_init();

    UART_SendString(DEV_USB_UART, (uint8_t*)"RGB\r\n");

    rgb_init();
    joystick_init();

    while (1) {

        joy = joystick_read();

        if ((joy & JOYSTICK_CENTER) != 0) {
            rgb_setLeds(RGB_RED|RGB_GREEN|RGB_BLUE);
            r = RGB_RED;
            b = RGB_BLUE;
            g = RGB_GREEN;
        }

        if ((joy & JOYSTICK_DOWN) != 0) {
            rgb_setLeds(0);
            r = g = b = 0;
        }

        if ((joy & JOYSTICK_LEFT) != 0) {
            r = !r;
            rgb_setLeds(r|g|b);
        }

        if ((joy & JOYSTICK_UP) != 0) {
            if(g)
                g = 0;
            else
                g = RGB_GREEN;
            rgb_setLeds(r|g|b);
        }

        if ((joy & JOYSTICK_RIGHT) != 0) {
            if(b)
                b = 0;
            else
                b = RGB_BLUE;
            rgb_setLeds(r|g|b);
        }


        brd_delayMs(200);
    }


}
