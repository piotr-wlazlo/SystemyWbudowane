/*****************************************************************************
 *   Reading data from UART1 and writing to UART2 (and vice versa)
 *
 *   Copyright(C) 2009, Embedded Artists AB
 *   All rights reserved.
 *
 ******************************************************************************/


#include "type.h"
#include "uart.h"
#include "stdio.h"
#include "timer32.h"
#include "gpio.h"
#include "i2c.h"

#include "uart2.h"



int main (void)
{
    uint8_t data = 0;

    uint8_t uart1Read = 1;
    uint32_t recvd = 0;
    uint32_t len = 0;

    GPIOInit();
    init_timer32(0, 10);

    I2CInit(I2CMASTER, 0);

    UARTInit(115200);
    uart2_init(115200, CHANNEL_A);

    if (uart1Read) {
        UARTSendString((uint8_t*)"\r\nReading data from this UART\r\n");
        uart2_sendString((uint8_t*)"\r\nWriting data from UART1 to this UART\r\n");
    }
    else {
        uart2_sendString((uint8_t*)"\r\nReading data from this UART\r\n");
        UARTSendString((uint8_t*)"\r\nWriting data from UART2 to this UART\r\n");
    }

    while (1) {
        if (uart1Read) {
            len = UARTReceive(&data, 1, FALSE);
        }
        else {
            len = uart2_receive(&data, 1, FALSE);
        }

        if (len > 0) {
            if (uart1Read) {
                uart2_send(&data, 1);
            }
            else {
                UARTSend(&data, 1);
            }

            recvd++;
        }

        if (recvd >= 10) {
            uart1Read = !uart1Read;

            if (uart1Read) {
                UARTSendString((uint8_t*)"\r\nReading data from this UART\r\n");
                uart2_sendString((uint8_t*)"\r\nWriting data from UART1 to this UART\r\n");
            }
            else {
                uart2_sendString((uint8_t*)"\r\nReading data from this UART\r\n");
                UARTSendString((uint8_t*)"\r\nWriting data from UART2 to this UART\r\n");
            }
            recvd = 0;
        }

        delay32Ms(0, 50);
    }


    while(1);

}
