/*****************************************************************************
 *   This example is controlling the LEDs using the joystick
 *
 *   Copyright(C) 2009, Embedded Artists AB
 *   All rights reserved.
 *
 ******************************************************************************/


#include "lpc_types.h"
#include "board.h"
#include "uart.h"
#include "stdio.h"
#include "timer32.h"
#include "gpio.h"
#include "i2c.h"

#include "joystick.h"
#include "pca9532.h"


int main (void) {

    uint8_t dir = 0;
    uint32_t delay = 100;
    uint32_t cnt = 0;
    uint16_t ledOn = 0;
    uint16_t ledOff = 0;

    uint8_t joy = 0;

    I2C_InitTypeDef i2cInit;

    brd_delay_init();
    brd_usb_uart_init();

    UART_SendString(DEV_USB_UART, (uint8_t*)"LEDs (PCA9532)\r\n");

    i2cInit.ClockRate = 100000;
    i2cInit.Mode      = I2C_MASTER;
    i2cInit.InterruptMode = I2C_INTERRUPT_MODE;
    I2C_Init(&i2cInit);

    pca9532_init();
    joystick_init();

    while (1) {

        joy = joystick_read();

        if ((joy & JOYSTICK_CENTER) != 0) {
            continue;
        }

        if ((joy & JOYSTICK_DOWN) != 0) {
            if (delay < 200)
                delay += 10;
        }

        if ((joy & JOYSTICK_UP) != 0) {
            if (delay > 30)
                delay -= 10;
        }

        if ((joy & JOYSTICK_LEFT) != 0) {
            dir = 0;
        }

        if ((joy & JOYSTICK_RIGHT) != 0) {
            dir = 1;
        }


        if (cnt < 16)
            ledOn |= (1 << cnt);
        if (cnt > 15)
            ledOn &= ~( 1 << (cnt - 16) );

        if (cnt > 15)
            ledOff |= ( 1 << (cnt - 16) );
        if (cnt < 16)
            ledOff &= ~(1 << cnt);

        pca9532_setLeds(ledOn, ledOff);

        if (dir) {
            if (cnt == 0)
                cnt = 31;
            else
                cnt--;

        } else {
            cnt++;
            if (cnt >= 32)
                cnt = 0;
        }

        brd_delayMs(delay);
    }


}
