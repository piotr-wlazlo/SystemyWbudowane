/*****************************************************************************
 *   This example shows how to read and write to the eeprom
 *
 *   Copyright(C) 2009, Embedded Artists AB
 *   All rights reserved.
 *
 ******************************************************************************/


#include "lpc_types.h"
#include "uart.h"
#include "stdio.h"
#include "timer32.h"
#include "i2c.h"
#include "gpio.h"
#include "string.h"
#include "board.h"


#include "eeprom.h"

#define E_WRITE_LEN 200

int main (void)
{
    int i = 0;
    uint16_t offset = 240;
    uint8_t b[E_WRITE_LEN];
    int16_t len = 0;
    I2C_InitTypeDef i2cInit;

    brd_delay_init();
    brd_usb_uart_init();

    UART_SendString(DEV_USB_UART, (uint8_t*)"EEPROM example\r\n");

    i2cInit.ClockRate = 100000;
    i2cInit.Mode      = I2C_MASTER;
    i2cInit.InterruptMode = I2C_INTERRUPT_MODE;
    I2C_Init(&i2cInit);

    for (i = 0; i < E_WRITE_LEN; i++) {
        b[i] = (uint8_t)(i+6);
    }

    eeprom_init();

    len = eeprom_write(b, offset, E_WRITE_LEN);

    if (len != E_WRITE_LEN) {
      UART_SendString(DEV_USB_UART,(uint8_t*)"EEPROM: Failed to write data\r\n");
        return 1;
    }

    UART_SendString(DEV_USB_UART, (uint8_t*)"EEPROM: Data written\r\n");
    brd_delayMs(2000);

    memset(b, 0, E_WRITE_LEN);

    UART_SendString(DEV_USB_UART, (uint8_t*)"EEPROM: Reading\r\n");
    len = eeprom_read(b, offset, E_WRITE_LEN);

    if (len != E_WRITE_LEN) {
      UART_SendString(DEV_USB_UART, (uint8_t*)"EEPROM: Failed to read all data\r\n");
        return 1;
    }

    UART_SendString(DEV_USB_UART, (uint8_t*)"EEPROM: Verifing\r\n");
    for (i = 0; i < E_WRITE_LEN; i++) {
        if (b[i] != (uint8_t)(i+6)) {

          UART_SendString(DEV_USB_UART, (uint8_t*)"EEPROM: Invalid data\r\n");

          return 1;
        }
    }

    UART_SendString(DEV_USB_UART, (uint8_t*)"EEPROM: OK\r\n");

    return 0;
}
