/**************************************************************************//**
 * $Id: lpc12xx_i2c.c 5070 2010-09-29 05:56:16Z cnh20509 $
 *
 * @file     lpc12xx_i2c.c
 * @brief    Contains all functions support for I2C firmware library on LPC12xx.
 * @version  1.0
 * @date     26. Sep. 2010
 * @author   NXP MCU Team
 *
 * @note
 * Copyright (C) 2010 NXP Semiconductors(NXP). All rights reserved.
 *
 * @par
 * Software that is described herein is for illustrative purposes only
 * which provides customers with programming information regarding the
 * products. This software is supplied "AS IS" without any warranties.
 * NXP Semiconductors assumes no responsibility or liability for the
 * use of the software, conveys no license or title under any patent,
 * copyright, or mask work right to the product. NXP Semiconductors
 * reserves the right to make changes in the software without
 * notification. NXP Semiconductors also make no representation or
 * warranty that such application will be suitable for the specified
 * use without further testing or modification.
 ******************************************************************************/
 
 /* Peripheral group ----------------------------------------------------------- */
/** @addtogroup I2C
 * @{
 */

/* Includes ------------------------------------------------------------------- */
#include "i2c.h"

/* If this source file built with example, the LPC12xx FW library configuration
 * file in each example directory ("lpc12xx_libcfg.h") must be included,
 * otherwise the default FW library configuration file must be included instead
 */
#ifdef __BUILD_WITH_EXAMPLE__
#include "libcfg.h"
#else
#include "libcfg_default.h"
#endif /* __BUILD_WITH_EXAMPLE__ */

#ifdef _I2C

#include "string.h"

static volatile uint8_t* I2CMasterBuffer;
static volatile uint8_t* I2CSlaveBuffer;
static volatile uint32_t I2CMasterState = I2C_IDLE;
static volatile uint32_t I2CReadLength, I2CWriteLength;
static volatile uint32_t RdIndex = 0;
static volatile uint32_t WrIndex = 0;
static volatile uint8_t I2CAddr;

#define RD_BIT          0x01
#define I2C_MAX_TIMEOUT   0x00FFFFFF

/** @defgroup 	I2C_Private_Functions
 * @{
 */

/**
  * @brief  Get I2C Status Byte.
  *
  *	@param	
  * @retval The value of the status byte.  
  */
uint8_t I2C_GetI2CStatus( void )
{
	return (LPC_I2C->STAT);
}

/**
  * @brief  Read the I2C_I2CONSET bit.
  *
  *	@param  I2C_I2CONSET: specifies the bits will be read.
  *         This parameter can be one of the following values:
  *				@arg I2C_I2CONSET_AA: Assert acknowledge flag
  *				@arg I2C_I2CONSET_SI: I2C interrupt flag
  *				@arg I2C_I2CONSET_STO: STOP flag
  *  			@arg I2C_I2CONSET_STA: START flag
  *				@arg I2C_I2CONSET_I2EN: I2C interface enable
  * @retval The I2C_CONSET bit value.  
  */
uint8_t I2C_ReadFlag( uint8_t I2C_I2CONSET )
{
  	CHECK_PARAM(PARAM_I2C_I2CONSET(I2C_I2CONSET));

	return(LPC_I2C->CONSET & I2C_I2CONSET);      /* retuen flag */
}

/**
  * @brief  Set the I2C_I2CONSET bit.
  *
  *	@param  I2C_I2CONSET: specifies the bits will be set.
  *         This parameter can be one of the following values:
  *				@arg I2C_I2CONSET_AA: Assert acknowledge flag
  *				@arg I2C_I2CONSET_SI: I2C interrupt flag
  *				@arg I2C_I2CONSET_STO: STOP flag
  *  			@arg I2C_I2CONSET_STA: START flag
  *				@arg I2C_I2CONSET_I2EN: I2C interface enable
  * @retval None  
  */
void I2C_SetFlag( uint8_t I2C_I2CONSET )
{
  	CHECK_PARAM(PARAM_I2C_I2CONSET(I2C_I2CONSET));

	LPC_I2C->CONSET = I2C_I2CONSET;      /* Set flag */
}

/**
  * @brief  Clear the I2C_I2CONCLR bit.
  *
  *	@param  I2C_I2CONCLR: specifies the bits will be clear.
  *         This parameter can be one of the following values:
  *				@arg I2C_I2CONSET_AA: Assert acknowledge flag
  *				@arg I2C_I2CONSET_SI: I2C interrupt flag
  *  			@arg I2C_I2CONSET_STA: START flag
  *				@arg I2C_I2CONSET_I2EN: I2C interface enable
  * @retval  
  */
void I2C_ClearFlag( uint8_t I2C_I2CONCLR )
{
	CHECK_PARAM(PARAM_I2C_I2CONCLR(I2C_I2CONCLR));

	LPC_I2C->CONCLR = I2C_I2CONCLR;      /* Clear flag */
}

/**
  * @brief  
  *
  *	@param  DataByte: specifies the data byte will be sent.
  * @retval None 
  */
void I2C_SendByte( uint8_t DataByte )
{
	LPC_I2C->DAT = DataByte; 
}
/**
  * @brief  
  *
  *	@param	
  * @retval The byte read from DAT register.  
  */

uint8_t I2C_GetByte( void )
{
	return(LPC_I2C->DAT);
}

/**
  * @brief  Setup clock rate for I2C peripheral.
  *
  *	@param	TargetClock: speed of I2C bus(bps).
  * @retval None  
  */
void I2C_SetClock (uint32_t TargetClock)
{
	uint32_t temp;

	temp = SystemCoreClock  / TargetClock;

	/* Set the I2C clock value to register */
	LPC_I2C->SCLH = (uint32_t)(temp / 2);
	LPC_I2C->SCLL = (uint32_t)(temp - LPC_I2C->SCLH);
}

/**
  * @brief  De-initializes the I2C peripheral registers to their default reset values.
  *
  * @param  None
  * @retval None  
  */
void I2C_DeInit(void)
{
	LPC_I2C->CONCLR = I2C_I2CONCLR_I2ENC;		/*!< Disable I2C control */
	LPC_SYSCON->SYSAHBCLKCTRL  =  LPC_SYSCON->SYSAHBCLKCTRL & (~(1<<5));	/*!< Disable power for I2C module */
}

/**
  * @brief  Initializes the i2c peripheral with specified parameter.
  *
  * @param  i2C_InitStruct: pointer to a I2C_InitStruct structure that 
  *         contains the configuration information for the I2C peripheral.
  * @retval None
  */
void I2C_Init(I2C_InitTypeDef* I2C_InitStuct)
{
	CHECK_PARAM(PARAM_I2C_MODE(I2C_InitStuct->Mode));
	CHECK_PARAM(PARAM_I2C_INTERRUPT_MODE(I2C_InitStuct->InterruptMode));

	/* Enable I2C clock and de-assert reset */
    LPC_SYSCON->PRESETCTRL |= (0x1<<1);
    LPC_SYSCON->SYSAHBCLKCTRL |= (1<<5);

	/*  I2C I/O config */    
    LPC_IOCON->PIO0_10 &= ~0x3F;	/*  I2C I/O config */
    LPC_IOCON->PIO0_10 |= 0x02;		/* I2C SCL */
    LPC_IOCON->PIO0_11 &= ~0x3F;
    LPC_IOCON->PIO0_11 |= 0x02;		/* I2C SDA */
    
	/*--- Clear flags ---*/
	LPC_I2C->CONCLR = I2C_I2CONCLR_AAC | I2C_I2CONCLR_SIC | I2C_I2CONCLR_STAC | I2C_I2CONCLR_I2ENC;    

	/*--- Enable Ture Open Drain mode ---*/
	LPC_IOCON->PIO0_10 |= (0x1<<10);
	LPC_IOCON->PIO0_11 |= (0x1<<10);

	/*--- Set Clock rate ---*/
	I2C_SetClock( I2C_InitStuct -> ClockRate );

	if ( I2C_InitStuct -> Mode == I2C_SLAVE )
	{
		LPC_I2C->ADR0 = I2C_InitStuct -> SlaveAddress;
	}    

	/* Enable the I2C Interrupt */
	if (I2C_InitStuct -> InterruptMode == I2C_INTERRUPT_MODE )
	{
		NVIC_EnableIRQ(I2C_IRQn);
	}
	else if (I2C_InitStuct -> InterruptMode == I2C_POLLING_MODE ) 	
	{
		NVIC_DisableIRQ(I2C_IRQn);		/* Disable the I2C Interrupt */
	}

	if ( I2C_InitStuct -> Mode == I2C_MASTER )
	{
		LPC_I2C->CONSET = I2C_I2CONSET_I2EN;
	} 
	else if (I2C_InitStuct -> Mode == I2C_SLAVE)
	{
		LPC_I2C->CONSET = I2C_I2CONSET_I2EN | I2C_I2CONSET_SI;
	}
}

/**
  * @brief  Configures functionality in I2C monitor mode.
  *
  *	@param	I2C_I2MMCTRL: Monitor mode configuration type.
  *         This parameter can be one of the following values:
  * 			@arg I2C_I2MMCTRL_MM_ENA: Enable monitor mode.
  * 			@arg I2C_I2MMCTRL_ENA_SCL: I2C module can 'stretch'
  * 					the clock line (hold it low) until it has had time to
  * 					respond to an I2C interrupt.
  *				@arg I2C_I2MMCTRL_MATCH_ALL: When this bit is set to '1'
  * 					and the I2C is in monitor mode, an interrupt will be
  * 					generated on ANY address received.
  *	@param	NewState: New State of this function, should be:
  * 			@arg ENABLE: Enable this function.
  * 			@arg DISABLE: Disable this function.
  * @retval None  
  */
void I2C_MonitorModeConfig(uint32_t I2C_I2MMCTRL, FunctionalState NewState)
{
	CHECK_PARAM(PARAM_I2C_I2MMCTRL(I2C_I2MMCTRL));

	if (NewState == ENABLE)
	{
		LPC_I2C->MMCTRL |= I2C_I2MMCTRL;
	}
	else
	{
		LPC_I2C->MMCTRL &= (~I2C_I2MMCTRL);
	}
}

/**
  * @brief  Get data from I2C data buffer in monitor mode.
  *
  * @param  None
  * @retval The value read from DATA_BUFFER.  
  *
  * Note:	In monitor mode, the I2C module may lose the ability to stretch
  * 		the clock (stall the bus) if the ENA_SCL bit is not set. This means that
  * 		the processor will have a limited amount of time to read the contents of
  * 		the data received on the bus. If the processor reads the I2DAT shift
  * 		register, as it ordinarily would, it could have only one bit-time to
  * 		respond to the interrupt before the received data is overwritten by
  * 		new data.
  */
uint8_t I2C_MonitorGetDatabuffer(void)
{
	return ((uint8_t)(LPC_I2C->DATA_BUFFER));
}

#if 0
/**
  * @brief  I2C master working at polling mode
  *
  * @param  None
  * @retval None
  */
void I2C_Master_Polling(void)
{
  uint8_t StatValue;
  while(I2CMasterState != I2C_OK)
  {
    if (I2C_ReadFlag(I2C_I2CONSET_SI))
    {
      StatValue = I2C_GetI2CStatus();
      switch ( StatValue )
      {
        case I2C_I2STAT_M_TX_START:       /* 0x08: A Start condition is issued. */
        WrIndex = 0;
        I2C_SendByte(I2CAddr);
        I2C_ClearFlag(I2C_I2CONCLR_SIC | I2C_I2CONCLR_STAC);
        break;

        case I2C_I2STAT_M_TX_RESTART:     /* 0x10: A repeated started is issued */
        RdIndex = 0;
        I2C_SendByte(I2CAddr);       /* Send SLA with R bit set */
        I2C_ClearFlag(I2C_I2CONCLR_SIC | I2C_I2CONCLR_STAC);
        break;

        case I2C_I2STAT_M_TX_SLAW_ACK:      /* 0x18: Regardless, it's a ACK */
        if ( I2CWriteLength == 1 )
        {
          I2C_SetFlag(I2C_I2CONSET_STO);              /* Set Stop flag */
          I2CMasterState = I2C_NO_DATA;
        }
        else
        {
          I2C_SendByte(I2CMasterBuffer[WrIndex++]);
        }
        I2C_ClearFlag(I2C_I2CONCLR_SIC);
        break;

        case I2C_I2STAT_M_TX_DAT_ACK:     /* 0x28: Data byte has been transmitted, regardless ACK or NACK */
        if ( WrIndex < I2CWriteLength )
        {
          I2C_SendByte(I2CMasterBuffer[WrIndex++]);   /* this should be the last one */
        }
        else
        {
          if ( I2CReadLength != 0 )
          {
            I2C_SetFlag(I2C_I2CONSET_STA);        /* Set Repeated-start flag */
          }
          else
          {
            I2C_SetFlag(I2C_I2CONSET_STO);        /* Set Stop flag */
            I2CMasterState = I2C_OK;
          }
        }
        I2C_ClearFlag(I2C_I2CONCLR_SIC);
        break;

        case I2C_I2STAT_M_TX_DAT_NACK:      /* 0x30: Data has been transmitted, NACK has been received */
        I2C_SetFlag(I2C_I2CONSET_STO);            /* Set Stop flag */
        I2CMasterState = I2C_NACK_ON_DATA;
        I2C_ClearFlag(I2C_I2CONCLR_SIC);
        break;

        case I2C_I2STAT_M_RX_SLAR_ACK:      /* 0x40: Master Receive, SLA_R has been sent */
        if ( (RdIndex + 1) < I2CReadLength )
        {
          /* Will go to State 0x50 */
          I2C_SetFlag(I2C_I2CONSET_AA);         /* assert ACK after data is received */
        }
        else
        {
          /* Will go to State 0x58 */
          I2C_ClearFlag(I2C_I2CONCLR_AAC);          /* assert NACK after data is received */
        }
        I2C_ClearFlag(I2C_I2CONCLR_SIC);
        break;

        case I2C_I2STAT_M_RX_DAT_ACK:     /* 0x50: Data byte has been received, regardless following ACK or NACK */
        I2CSlaveBuffer[RdIndex++] = I2C_GetByte();
        if ( (RdIndex + 1) < I2CReadLength )
        {
          I2C_SetFlag(I2C_I2CONSET_AA);         /* assert ACK after data is received */
        }
        else
        {
          I2C_ClearFlag(I2C_I2CONCLR_AAC);          /* assert NACK on last byte */
        }
        I2C_ClearFlag(I2C_I2CONCLR_SIC);
        break;

        case I2C_I2STAT_M_RX_DAT_NACK:      /*0x58: Data has been received, NACK has been return */
        I2CSlaveBuffer[RdIndex++] = I2C_GetByte();
        I2CMasterState = I2C_OK;
        I2C_SetFlag(I2C_I2CONSET_STO);            /* Set Stop flag */
        I2C_ClearFlag(I2C_I2CONCLR_SIC);            /* Clear SI flag */
        break;

        case I2C_I2STAT_M_TX_SLAW_NACK:     /*0x20: SLA+W has been transmitted, NACK has been received */
        case I2C_I2STAT_M_RX_SLAR_NACK:     /*0x48: SLA+R has been transmitted, NACK has been received */
        I2C_SetFlag(I2C_I2CONSET_STO);            /* Set Stop flag */
        I2CMasterState = I2C_NACK_ON_ADDRESS;
        I2C_ClearFlag(I2C_I2CONCLR_SIC);
        break;

        case I2C_I2STAT_M_TX_ARB_LOST:      /*0x38: Arbitration lost, in this example, we don't deal with multiple master situation */
        default:
        I2CMasterState = I2C_ARBITRATION_LOST;
        I2C_ClearFlag(I2C_I2CONCLR_SIC);
        break;
      }
    }
  }
}
#endif

/**
  * @brief  General Master Interrupt handler for I2C peripheral
  *
  * @param  None
  * @retval None
  */
void I2C_IRQHandler(void)
{
  uint8_t StatValue;

  StatValue = I2C_GetI2CStatus();
  switch ( StatValue )
  {
    case I2C_I2STAT_M_TX_START:       /* 0x08: A Start condition is issued. */
      WrIndex = 0;
      I2C_SendByte(I2CAddr);
      I2C_ClearFlag(I2C_I2CONCLR_SIC | I2C_I2CONCLR_STAC);
      I2CMasterState = I2C_STARTED;
      break;

    case I2C_I2STAT_M_TX_RESTART:     /* 0x10: A repeated started is issued */
      RdIndex = 0;
      I2C_SendByte(I2CAddr);       /* Send SLA with R bit set */
      I2C_ClearFlag(I2C_I2CONCLR_SIC | I2C_I2CONCLR_STAC);
      I2CMasterState = I2C_RESTARTED;
      break;

    case I2C_I2STAT_M_TX_SLAW_ACK:      /* 0x18: Regardless, it's a ACK */

      if (I2CMasterState == I2C_STARTED)
      {
        I2C_SendByte(I2CMasterBuffer[WrIndex++]);
        I2CMasterState = DATA_ACK;
      }

      I2C_ClearFlag(I2C_I2CONCLR_SIC);
      break;

    case I2C_I2STAT_M_TX_DAT_ACK:     /* 0x28: Data byte has been transmitted, regardless ACK or NACK */
    case I2C_I2STAT_M_TX_DAT_NACK:      /* 0x30: Data has been transmitted, NACK has been received */
      if (WrIndex < I2CWriteLength)
      {
        I2C_SendByte(I2CMasterBuffer[WrIndex++]);
        I2CMasterState = DATA_ACK;
      }
      else
      {
        if (I2CReadLength != 0)
        {
          I2C_SetFlag(I2C_I2CONSET_STA);        /* Set Repeated-start flag */
          I2CMasterState = I2C_REPEATED_START;
        }
        else
        {
          I2CMasterState = DATA_NACK;
          I2C_SetFlag(I2C_I2CONSET_STO);            /* Set Stop flag */
        }
      }

      I2C_ClearFlag(I2C_I2CONCLR_SIC);
      break;

    case I2C_I2STAT_M_RX_SLAR_ACK:      /* 0x40: Master Receive, SLA_R has been sent */

      if (I2CReadLength == 1)
      {
        /* Will go to State 0x58 */
        I2C_ClearFlag(I2C_I2CONCLR_AAC);        /* assert NACK after data is received */
      }
      else
      {
        /* Will go to State 0x50 */
        I2C_SetFlag(I2C_I2CONSET_AA);         /* assert ACK after data is received */
      }

      I2C_ClearFlag(I2C_I2CONCLR_SIC);
      break;

    case I2C_I2STAT_M_RX_DAT_ACK:     /* 0x50: Data byte has been received, regardless following ACK or NACK */
      I2CSlaveBuffer[RdIndex++] = I2C_GetByte();
      if ( RdIndex < I2CReadLength )
      {
        I2CMasterState = DATA_ACK;
        I2C_SetFlag(I2C_I2CONSET_AA);         /* assert ACK after data is received */
      }
      else
      {
        I2CMasterState = DATA_NACK;
        I2C_ClearFlag(I2C_I2CONCLR_AAC);        /* assert NACK on last byte */
      }
      I2C_ClearFlag(I2C_I2CONCLR_SIC);
      break;

    case I2C_I2STAT_M_RX_DAT_NACK:      /*0x58: Data has been received, NACK has been return */
      I2CSlaveBuffer[RdIndex++] = I2C_GetByte();
      I2CMasterState = DATA_NACK;
      I2C_SetFlag(I2C_I2CONSET_STO);            /* Set Stop flag */
      I2C_ClearFlag(I2C_I2CONCLR_SIC);          /* Clear SI flag */
      break;

    case I2C_I2STAT_M_TX_SLAW_NACK:     /*0x20: SLA+W has been transmitted, NACK has been received */
    case I2C_I2STAT_M_RX_SLAR_NACK:     /*0x48: SLA+R has been transmitted, NACK has been received */
      I2C_ClearFlag(I2C_I2CONCLR_SIC);
      I2CMasterState = DATA_NACK;

      break;

    case I2C_I2STAT_M_TX_ARB_LOST:      /*0x38: Arbitration lost, in this example, we don't deal with multiple master situation */
    default:

      I2C_ClearFlag(I2C_I2CONCLR_SIC);
      break;
  }
  return;
}

uint32_t I2CStart(void)
{
  uint32_t timeout = 0;
  uint32_t retVal = FALSE;

  /*--- Issue a start condition ---*/
  I2C_SetFlag(I2C_I2CONSET_STA);

  /*--- Wait until START transmitted ---*/
  while (1)
  {
    if ( I2CMasterState == I2C_STARTED )
    {
      retVal = TRUE;
      break;
    }
    if ( timeout >= I2C_MAX_TIMEOUT )
    {
      retVal = FALSE;
      break;
    }
    timeout++;
  }

  return retVal;
}

uint32_t I2CStop(void)
{
  I2C_SetFlag(I2C_I2CONSET_STO);
  I2C_ClearFlag(I2C_I2CONCLR_SIC);

  while (I2C_ReadFlag( I2C_I2CONSET_STO ));

  return TRUE;
}

uint32_t I2CEngine(void)
{
  I2CMasterState = I2C_IDLE;
  RdIndex = 0;
  WrIndex = 0;

  if (I2CStart() != TRUE)
  {
    I2CStop();
    return FALSE;
  }

  while (1)
  {
    if (I2CMasterState == DATA_NACK)
    {
      I2CStop();
      break;
    }
  }

  return TRUE;
}

void I2CWrite(uint8_t addr, uint8_t* buf, uint32_t len)
{
  I2CWriteLength = len;
  I2CReadLength = 0;
  I2CAddr = addr;
  I2CMasterBuffer = buf;

  I2CMasterState = I2C_IDLE;

  //I2C_SetFlag(I2C_I2CONSET_STA);  /* Set start condition*/
  I2CEngine();
}

void I2CRead(uint8_t addr, uint8_t* buf, uint32_t len)
{
  I2CWriteLength = 1;
  I2CReadLength = len;
  I2CAddr = addr | RD_BIT;
  I2CSlaveBuffer = buf;

  I2CMasterState = I2C_IDLE;

  //I2C_SetFlag(I2C_I2CONSET_STA);  /* Set start condition*/
  I2CEngine();

}

/**
 * @}
 */

#endif // _I2C

/**
 * @}
 */
/* --------------------------------- End Of File ------------------------------ */
