uart2
=========
This project contains a simple example reading data from UART1 
and writing to UART2 (and vice versa) 

The project makes use of code from the following library projects:
- Lib_CMSIS 	  : for CMSIS files
- Lib_MCU         : for LPC12xx peripheral driver files
- Lib_EaBaseBoard : for Embedded Artists LPCXpresso Base Board peripheral drivers

These library projects must exist in the same workspace in order
for the project to successfully build.

