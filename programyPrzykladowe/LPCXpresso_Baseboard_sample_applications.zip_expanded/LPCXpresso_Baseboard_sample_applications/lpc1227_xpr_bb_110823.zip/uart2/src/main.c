/*****************************************************************************
 *   Reading data from UART1 and writing to UART2 (and vice versa)
 *
 *   Copyright(C) 2009, Embedded Artists AB
 *   All rights reserved.
 *
 ******************************************************************************/


#include "lpc_types.h"
#include "board.h"
#include "uart.h"
#include "stdio.h"
#include "timer32.h"
#include "gpio.h"
#include "i2c.h"

#include "uart2.h"



int main (void)
{
  uint8_t data = 0;

  uint8_t uart1Read = 1;
  uint32_t recvd = 0;
  uint32_t len = 0;

  I2C_InitTypeDef i2cInit;

  brd_delay_init();
  brd_usb_uart_init();

  i2cInit.ClockRate = 100000;
  i2cInit.Mode      = I2C_MASTER;
  i2cInit.InterruptMode = I2C_INTERRUPT_MODE;
  I2C_Init(&i2cInit);

  uart2_init(115200, CHANNEL_A);

  if (uart1Read) {
    UART_SendString(DEV_USB_UART, (uint8_t*)"\r\nReading data from this UART\r\n");
    uart2_sendString((uint8_t*)"\r\nWriting data from UART1 to this UART\r\n");
  }
  else {
    uart2_sendString((uint8_t*)"\r\nReading data from this UART\r\n");
    UART_SendString(DEV_USB_UART, (uint8_t*)"\r\nWriting data from UART2 to this UART\r\n");
  }

  while (1) {
    if (uart1Read) {
      len = UART_Receive(DEV_USB_UART, &data, 1, UART_BLOKING_TIMEOUT);
    }
    else {
      len = uart2_receive(&data, 1, FALSE);
    }

    if (len > 0) {
      if (uart1Read) {
        uart2_send(&data, 1);
      }
      else {
        UART_Send(DEV_USB_UART, &data, 1, UART_BLOKING_TIMEOUT);
      }

      recvd++;
    }

    if (recvd >= 10) {
      uart1Read = !uart1Read;

      if (uart1Read) {
        UART_SendString(DEV_USB_UART, (uint8_t*)"\r\nReading data from this UART\r\n");
        uart2_sendString((uint8_t*)"\r\nWriting data from UART1 to this UART\r\n");
      }
      else {
        uart2_sendString((uint8_t*)"\r\nReading data from this UART\r\n");
        UART_SendString(DEV_USB_UART, (uint8_t*)"\r\nWriting data from UART2 to this UART\r\n");
      }
      recvd = 0;
    }

    brd_delayMs(50);
  }


  while(1);

}
