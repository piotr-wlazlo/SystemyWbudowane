/*****************************************************************************
 *   This project contains a simple example only trying to contact
 *   the Xbee module. The result is presented on the OLED display.
 *
 *   Copyright(C) 2009, Embedded Artists AB
 *   All rights reserved.
 *
 ******************************************************************************/


#include "lpc_types.h"
#include "board.h"
#include "uart.h"
#include "stdio.h"
#include "timer32.h"
#include "gpio.h"
#include "ssp.h"
#include "sysctrl.h"
#include "iocon.h"

#include "oled.h"

#define DEV_XBEE_UART (LPC_UART0)

static void xbee_uart_init(void)
{
  IOCON_PIO_CFG_Type PIO_mode;
  UART_CFG_Type uartCfg;

  IOCON_StructInit(&PIO_mode);
  PIO_mode.type = IOCON_UART_RXD0_LOC0;
  IOCON_SetFunc(&PIO_mode);
  PIO_mode.type = IOCON_UART_TXD0_LOC0;
  IOCON_SetFunc(&PIO_mode);

  SYS_ResetPeripheral(SYS_PRESETCTRL_UART0_RST,DISABLE);
  SYS_ConfigAHBCLK(SYS_AHBCLKCTRL_UART0, ENABLE);
  SYS_SetUART0ClockDiv(1);

  UART_Init(DEV_XBEE_UART);
  uartCfg.baudrate = 9600;
  uartCfg.databits = UART_CFG_DATABIT_8;
  uartCfg.stopbits = UART_CFG_STOPBIT_1;
  uartCfg.parity   = UART_CFG_PARITY_NONE;
  uartCfg.fifodma  = UART_CFG_DMAMODE_DISABLE;
  uartCfg.fifolevel= UART_CFG_FIFOTRG_1;
  uartCfg.txdbreak = UART_CFG_TXDBREAK_DISABLE;

  UART_SetConfig(DEV_XBEE_UART, &uartCfg);
  UART_ConfigTXD(DEV_XBEE_UART, ENABLE);

}

int main (void)
{
    uint8_t buf[100];
    uint32_t len = 0;
    uint8_t row = 1;
    uint32_t pos = 0;
    uint32_t startPos = 0;
    uint8_t ch = 0;
    uint32_t time = 0;

    SSP_InitTypeDef SSP_InitStructure;

    brd_delay_init();

    xbee_uart_init();

    SSP_StructInit(&SSP_InitStructure);
    SSP_Init(&SSP_InitStructure);
    SSP_Cmd (ENABLE);

    oled_init();


    oled_clearScreen(OLED_COLOR_WHITE);

    oled_putString(1,1,  (uint8_t*)"Contacting XBee", OLED_COLOR_BLACK, OLED_COLOR_WHITE);

    UART_SendString(DEV_XBEE_UART, (uint8_t*)"+++");
    brd_delayMs(1100);
    UART_SendString(DEV_XBEE_UART, (uint8_t*)"ATVL\r\n");

    while (1) {
        len = UART_Receive(DEV_XBEE_UART, &buf[pos], 1, UART_BLOKING_TIMEOUT);

        if (len > 0) {
            if (buf[pos] == '\r' || buf[pos] == '\n') {
                buf[pos] = '\0';
                oled_putString(1,1+row*8,  &buf[startPos], OLED_COLOR_BLACK, OLED_COLOR_WHITE);
                row++;
                startPos = pos+1;
            }
            else if ((pos - startPos) == 15) {
                ch = buf[pos];
                buf[pos] = '\0';
                oled_putString(1,1+row*8,  &buf[startPos], OLED_COLOR_BLACK, OLED_COLOR_WHITE);
                buf[pos] = ch;
                startPos = pos;
                row++;
            }
        }

        pos += len;

        if (row > 5 || len > 60)
            break;

        brd_delayMs(1);
        time++;

        if (time > 3000)
            break;
    }


    if ((row < 5 && len < 60) || time >= 3000)
        oled_putString(1,1+row*8,  (uint8_t*)"No contact!", OLED_COLOR_BLACK, OLED_COLOR_WHITE);

    while(1);

}
