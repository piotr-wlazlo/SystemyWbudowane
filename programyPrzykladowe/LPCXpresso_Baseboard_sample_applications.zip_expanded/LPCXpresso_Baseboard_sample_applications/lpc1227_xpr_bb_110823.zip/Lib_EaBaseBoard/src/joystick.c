/*****************************************************************************
 *   joystick.c:  Driver for the Joystick switch
 *
 *   Copyright(C) 2009, Embedded Artists AB
 *   All rights reserved.
 *
 ******************************************************************************/

/*
 * NOTE: GPIOInit must have been called before using any functions in this
 * file.
 *
 */


/******************************************************************************
 * Includes
 *****************************************************************************/

#include "mcu_regs.h"
#include "lpc_types.h"
#include "gpio.h"
#include "joystick.h"
#include "sysctrl.h"

/******************************************************************************
 * Defines and typedefs
 *****************************************************************************/

/******************************************************************************
 * External global variables
 *****************************************************************************/

/******************************************************************************
 * Local variables
 *****************************************************************************/


/******************************************************************************
 * Local Functions
 *****************************************************************************/


/******************************************************************************
 * Public Functions
 *****************************************************************************/

/******************************************************************************
 *
 * Description:
 *    Initialize the Joystick Driver
 *
 *****************************************************************************/
void joystick_init (void)
{
  SYS_ConfigAHBCLK(SYS_AHBCLKCTRL_GPIO0, ENABLE);

  /* set the GPIOs as inputs */
  GPIO_SetDir(LPC_GPIO0, 3, 0);
  GPIO_SetDir(LPC_GPIO0, 9, 0);
  GPIO_SetDir(LPC_GPIO0, 8, 0);
  GPIO_SetDir(LPC_GPIO0, 6, 0);
  GPIO_SetDir(LPC_GPIO0, 21, 0);
}

/******************************************************************************
 *
 * Description:
 *    Read the joystick status
 *
 * Returns:
 *   The joystick status. The returned value is a bit mask. More than one
 *   direction may be active at any given time (e.g. UP and RIGHT)
 *
 *****************************************************************************/
uint8_t joystick_read(void)
{
    uint8_t status = 0;

    if (/*!GPIOGetValue( PORT2, 0)*/!GPIO_GetPinValue(LPC_GPIO0, 3)) {
        status |= JOYSTICK_CENTER;
    }

    if (/*!GPIOGetValue( PORT2, 1)*/!GPIO_GetPinValue(LPC_GPIO0, 9)) {
        status |= JOYSTICK_DOWN;
    }

    if (/*!GPIOGetValue( PORT2, 2)*/!GPIO_GetPinValue(LPC_GPIO0, 8)) {
        status |= JOYSTICK_RIGHT;
    }

    if (/*!GPIOGetValue( PORT2, 3)*/!GPIO_GetPinValue(LPC_GPIO0, 6)) {
        status |= JOYSTICK_UP;
    }

    if (/*!GPIOGetValue( PORT3, 4)*/!GPIO_GetPinValue(LPC_GPIO0, 21)) {
        status |= JOYSTICK_LEFT;
    }

    return status;
}





