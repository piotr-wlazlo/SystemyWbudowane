/*****************************************************************************
 *   joystick.c:  Driver for the Joystick switch
 *
 *   Copyright(C) 2009, Embedded Artists AB
 *   All rights reserved.
 *
 ******************************************************************************/

/*
 * NOTE: GPIOInit must have been called before using any functions in this
 * file.
 *
 */


/******************************************************************************
 * Includes
 *****************************************************************************/

#include "mcu_regs.h"
#include "type.h"
#include "gpio.h"
#include "joystick.h"

/******************************************************************************
 * Defines and typedefs
 *****************************************************************************/

/******************************************************************************
 * External global variables
 *****************************************************************************/

/******************************************************************************
 * Local variables
 *****************************************************************************/


/******************************************************************************
 * Local Functions
 *****************************************************************************/


/******************************************************************************
 * Public Functions
 *****************************************************************************/

/******************************************************************************
 *
 * Description:
 *    Initialize the Joystick Driver
 *
 *****************************************************************************/
void joystick_init (void)
{
    /* set the GPIOs as inputs */
    GPIOSetDir( PORT1, 19, 0 );
    GPIOSetDir( PORT1, 20, 0 );
    GPIOSetDir( PORT1, 21, 0 );
    GPIOSetDir( PORT1, 22, 0 );
    GPIOSetDir( PORT1, 23, 0 );

}

/******************************************************************************
 *
 * Description:
 *    Read the joystick status
 *
 * Returns:
 *   The joystick status. The returned value is a bit mask. More than one
 *   direction may be active at any given time (e.g. UP and RIGHT)
 *
 *****************************************************************************/
uint8_t joystick_read(void)
{
    uint8_t status = 0;

    if (!GPIOGetPinValue( PORT1, 19)) {
        status |= JOYSTICK_CENTER;
    }

    if (!GPIOGetPinValue( PORT1, 20)) {
        status |= JOYSTICK_DOWN;
    }

    if (!GPIOGetPinValue( PORT1, 21)) {
        status |= JOYSTICK_RIGHT;
    }

    if (!GPIOGetPinValue( PORT1, 22)) {
        status |= JOYSTICK_UP;
    }

    if (!GPIOGetPinValue( PORT1, 23)) {
        status |= JOYSTICK_LEFT;
    }


    return status;
}





