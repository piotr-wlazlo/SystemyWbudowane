/*****************************************************************************
 *   This example shows how to read and write to the SPI Flash
 *
 *   Copyright(C) 2009, Embedded Artists AB
 *   All rights reserved.
 *
 ******************************************************************************/


#include "type.h"
#include "uart.h"
#include "stdio.h"
#include "timer32.h"
#include "ssp.h"
#include "gpio.h"
#include "string.h"


#include "flash.h"

#define E_WRITE_LEN (264*4)

static uint8_t buf[10];

static void intToString(int value, uint8_t* pBuf, uint32_t len, uint32_t base)
{
    static const char* pAscii = "0123456789abcdefghijklmnopqrstuvwxyz";
    int pos = 0;
    int tmpValue = value;

    // the buffer must not be null and at least have a length of 2 to handle one
    // digit and null-terminator
    if (pBuf == NULL || len < 2)
    {
        return;
    }

    // a valid base cannot be less than 2 or larger than 36
    // a base value of 2 means binary representation. A value of 1 would mean only zeros
    // a base larger than 36 can only be used if a larger alphabet were used.
    if (base < 2 || base > 36)
    {
        return;
    }

    // negative value
    if (value < 0)
    {
        tmpValue = -tmpValue;
        value    = -value;
        pBuf[pos++] = '-';
    }

    // calculate the required length of the buffer
    do {
        pos++;
        tmpValue /= base;
    } while(tmpValue > 0);


    if (pos > len)
    {
        // the len parameter is invalid.
        return;
    }

    pBuf[pos] = '\0';

    do {
        pBuf[--pos] = pAscii[value % base];
        value /= base;
    } while(value > 0);

    return;

}

int main (void)
{
    int i = 0;
    uint32_t offset = 240;
    uint8_t b[E_WRITE_LEN];
    int32_t len = 0;
    uint16_t psz = 0;

    GPIOInit();
    init_timer32(0, 10);

    UARTInit(115200);
    UARTSendString((uint8_t*)"Flash example\r\n");

    SSPInit();

    for (i = 0; i < E_WRITE_LEN; i++) {
        b[i] = (uint8_t)(i);
    }

    if (!flash_init()) {
        UARTSendString((uint8_t*)"Flash: Failed to initialize\r\n");
        return 1;
    }
    psz = flash_getPageSize();
    intToString(psz, buf, 10, 10);
    UARTSendString((uint8_t*)"Flash: Page size = ");
    UARTSendString(buf);
    UARTSendString((uint8_t*)"\r\n");

    len = flash_write(b, offset, E_WRITE_LEN);

    if (len != E_WRITE_LEN) {
        UARTSendString((uint8_t*)"Flash: Failed to write data\r\n");
        return 1;
    }

    UARTSendString((uint8_t*)"Flash: Data written\r\n");
    delay32Ms(0, 2000);

    memset(b, 0, E_WRITE_LEN);

    UARTSendString((uint8_t*)"Flash: Reading\r\n");
    len = flash_read(b, offset, E_WRITE_LEN);

    if (len != E_WRITE_LEN) {
        UARTSendString((uint8_t*)"Flash: Failed to read all data\r\n");
        return 1;
    }

    UARTSendString((uint8_t*)"Flash: Verifing\r\n");
    for (i = 0; i < E_WRITE_LEN; i++) {
        if (b[i] != (uint8_t)(i)) {

            UARTSendString((uint8_t*)"Flash: Invalid data\r\n");

            return 1;
        }
    }

    UARTSendString((uint8_t*) "Flash: OK\r\n");

    return 0;
}
