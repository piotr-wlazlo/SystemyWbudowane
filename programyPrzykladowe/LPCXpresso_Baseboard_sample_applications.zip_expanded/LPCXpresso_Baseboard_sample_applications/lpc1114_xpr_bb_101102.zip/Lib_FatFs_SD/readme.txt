This library project contains ChaN's Fat FS Module ported
to the LPCXpresso Base Board.

http://elm-chan.org/fsw/ff/00index_e.html





