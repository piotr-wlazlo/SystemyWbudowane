/*****************************************************************************
 *   board.h:  Header file for board configuration and helper functions
 *
 *   Copyright(C) 2011, Embedded Artists AB
 *   All rights reserved.
 *
******************************************************************************/
#ifndef __BOARD_H
#define __BOARD_H


/* UART on USB-to-UART bridge (FTDI) */
#define DEV_USB_UART (LPC_UART0)

/* Timer32 0 is used for delay helper function */
#define DEV_DELAY (LPC_CT32B0)

/* ADC channel for trim potentiometer */
#define BRD_ADC_TRIMPOT_CHANNEL ADC_CHANNEL_0

/* ADC channel for BNC */
#define BRD_ADC_BNC_CHANNEL ADC_CHANNEL_5

void brd_delay_init (void);
void brd_delayMs(uint32_t delay);
void brd_delayUs(uint32_t delay);

void brd_usb_uart_init(void);
void brd_trimpot_init(void);
void brd_bnc_init(void);




#endif /* end __BOARD_H */
/****************************************************************************
**                            End Of File
*****************************************************************************/
