BNC_OLED_XPR_BB : 
This project contains a an example reading values from BNC displaying the values on the OLED display.

DEMO_XPR_BB: 
This project contains a an example using several of the peripherals on the LPCXpresso base Board.With the joystick it is possible to draw on the OLED display, With the Rotary it is possible to control the 7-segment display, With the trimpot it is possible to control the RGB LED. Moving the board (accelerometer) will control a running pattern on the LEDs. Click SW3 button to start playing a melody on the Speaker

DISP7SEG_ROTARY_XPR_BB:
This project contains a an example using the rotary switch to change numbers on the 7-segment display.

I2C_EEPROM_XPR_BB: 
This project contains a an example showing how to read and write to the i2c-eeprom.

LEDS_JOYSTICK_XPR_BB:
This project contains a an example controlling the LEDs (4-19) using the joystick.

OLED_PERIHPH_XPR_BB:
This project contains a an example monitoring the light sensor, accelerometer and trim potentiometer and displaying the values on the OLED display.

OLED_WEB_XPR_BB:
This project connects to ethernet and prints out the IP Address on the oled display.

RGB_JOYSTICK_XPR_BB:
This project contains a an example controlling the RGB LED using the joystick.

SD_CARD_XPR_BB:
This project contains a an example showing how to access a MMC/SD card.

SPEAKER_TONE_XPR_BB:
This project contains a an example playing tones/notes on the speaker

SPEAKER_WAV_XPR_BB:
This project contains a an example playing a WAV file (on Speaker)

SPI_FLASH_XPR_BB:
This project contains a an example showing how to read and write to the spi-flash.

TEMPERATURE_XPR_BB:
This project contains a an example monitoring temperature sensor and print out the value on the terminal.

UART2_XPR_BB:
This project contains a simple example reading data from UART1 and writing to UART2 (and vice versa).

USB_HOST_LITE_XPR_BB:
The project will write a file named MSMYFILE.txt to the mass storage device, then open the file for reading and display the content on the oled display.

XBEE_OLED_XPR_BB:
This project contains a simple example only trying to contact the Xbee module. The result is presented on the OLED display.


Setup of the baseboard:
Please set all jumpers on the board for the different examples according to LPCXpresso BaseBoard Users Guide.



