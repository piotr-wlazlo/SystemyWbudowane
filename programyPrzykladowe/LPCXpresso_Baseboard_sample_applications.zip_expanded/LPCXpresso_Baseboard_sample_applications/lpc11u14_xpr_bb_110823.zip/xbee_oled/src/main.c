/*****************************************************************************
 *   This project contains a simple example only trying to contact
 *   the Xbee module. The result is presented on the OLED display.
 *
 *   Copyright(C) 2009, Embedded Artists AB
 *   All rights reserved.
 *
 ******************************************************************************/


#include "type.h"
#include "uart.h"
#include "stdio.h"
#include "timer32.h"
#include "gpio.h"
#include "ssp.h"

#include "oled.h"



int main (void)
{
    uint8_t buf[100];
    uint32_t len = 0;
    uint8_t row = 1;
    uint32_t pos = 0;
    uint32_t startPos = 0;
    uint8_t ch = 0;
    uint32_t time = 0;

    GPIOInit();
    init_timer32(0, 10);

    UARTInit(9600);

    SSP_IOConfig(0);
    SSP_Init(0);

    oled_init();


    oled_clearScreen(OLED_COLOR_WHITE);

    oled_putString(1,1,  (uint8_t*)"Contacting XBee", OLED_COLOR_BLACK, OLED_COLOR_WHITE);

    UARTSendString((uint8_t*)"+++");
    delay32Ms(0, 1100);
    UARTSendString((uint8_t*)"ATVL\r\n");

    while (1) {
        len = UARTReceive(&buf[pos], 1, FALSE);

        if (len > 0) {
            if (buf[pos] == '\r' || buf[pos] == '\n') {
                buf[pos] = '\0';
                oled_putString(1,1+row*8,  &buf[startPos], OLED_COLOR_BLACK, OLED_COLOR_WHITE);
                row++;
                startPos = pos+1;
            }
            else if ((pos - startPos) == 15) {
                ch = buf[pos];
                buf[pos] = '\0';
                oled_putString(1,1+row*8,  &buf[startPos], OLED_COLOR_BLACK, OLED_COLOR_WHITE);
                buf[pos] = ch;
                startPos = pos;
                row++;
            }
        }

        pos += len;

        if (row > 5 || len > 60)
            break;

        delay32Ms(0, 1);
        time++;

        if (time > 3000)
            break;
    }


    if ((row < 5 && len < 60) || time >= 3000)
        oled_putString(1,1+row*8,  (uint8_t*)"No contact!", OLED_COLOR_BLACK, OLED_COLOR_WHITE);

    while(1);

}
