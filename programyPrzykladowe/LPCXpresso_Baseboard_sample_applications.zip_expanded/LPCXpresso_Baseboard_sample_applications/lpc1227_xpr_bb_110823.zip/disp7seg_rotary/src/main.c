/*****************************************************************************
 *   An example illustrating how to control the 7-segment display
 *   using the Rotary switch
 *
 *   Copyright(C) 2009, Embedded Artists AB
 *   All rights reserved.
 *
 ******************************************************************************/

#include "lpc_types.h"
#include "board.h"
#include "uart.h"
#include "stdio.h"
#include "timer32.h"
#include "gpio.h"
#include "ssp.h"

#include "led7seg.h"
#include "rotary.h"

#include "iocon.h"
#include "sysctrl.h"


int main (void) {

    SSP_InitTypeDef SSP_InitStructure;
    uint8_t state    = 0;
    uint8_t ch = '0';

    brd_delay_init();
    brd_usb_uart_init();

    UART_SendString(DEV_USB_UART, (uint8_t*)"7-segment Display and Rotary\r\n");

    SSP_StructInit(&SSP_InitStructure);
    SSP_InitStructure.ClockRate = 1000000;
    SSP_Init(&SSP_InitStructure);
    SSP_Cmd (ENABLE);


    rotary_init();
    led7seg_init();

    while(1) {
        state = rotary_read();

        if (state != ROTARY_WAIT) {

            if (state == ROTARY_RIGHT) {
                ch++;
            }
            else {
                ch--;
            }

            if (ch > '9')
                ch = '0';
            else if (ch < '0')
                ch = '9';

            led7seg_setChar(ch, FALSE);

        }

    }

}
