spi_flash
=========
This project contains a an example showing how to read and
write to the spi-flash.

The project makes use of code from the following library projects:
- CMSISv2p10_LPC13Uxx : for CMSIS 2.10 files relevant to LPC1347
- LPC13Uxx_DriverLib  : for LPC13xx peripheral driver files
- EaBaseBoard_Lib     : for Embedded Artists LPCXpresso Base Board peripheral drivers

These library projects must exist in the same workspace in order
for the project to successfully build.

